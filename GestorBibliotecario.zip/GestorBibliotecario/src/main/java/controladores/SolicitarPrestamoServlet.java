package controladores;

import java.io.*;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import logica.ClaseEstudiante;
import logica.ClaseLibro;
import logica.ClasePrestamo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

@WebServlet(name = "solicitarPrestamoServlet", urlPatterns = {"/SolicitarPrestamoServlet"})
public class SolicitarPrestamoServlet extends HttpServlet {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sessionFactory.openSession();

        List<ClaseEstudiante> listaEstudiante = session.createQuery("FROM ClaseEstudiante ", ClaseEstudiante.class).getResultList();
        List<ClaseLibro> listaLibros = session.createQuery("FROM ClaseLibro ", ClaseLibro.class).getResultList();
        List<ClasePrestamo> listaPrestamo = session.createQuery("FROM ClasePrestamo ", ClasePrestamo.class).getResultList();

        session.close();
        sessionFactory.close();

        HttpSession sesion = req.getSession();
        sesion.setAttribute("listaProductos", listaEstudiante);
        sesion.setAttribute("listaLibros", listaLibros);
        sesion.setAttribute("listaPrestamo", listaPrestamo);

        response.sendRedirect("solicitarPrestamo.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ClasePrestamo prestamo = new ClasePrestamo();
        prestamo.setIdPrestamo(req.getParameter("idPrestamo"));
        prestamo.setCedula(req.getParameter("cedula"));
        prestamo.setIdLibro(req.getParameter("idLibro"));
        prestamo.setFechaPrestamo(Date.valueOf(LocalDate.parse(req.getParameter("fechaPrestamo"), formatter)));
        prestamo.setFechaPrestamo(Date.valueOf(LocalDate.parse(req.getParameter("fechaDevolucion"), formatter)));

        // Enviar prestamo a BD
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory()) {
            Session session = sessionFactory.openSession();
            // save the student object
            session.save(prestamo);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void destroy() {
    }
}

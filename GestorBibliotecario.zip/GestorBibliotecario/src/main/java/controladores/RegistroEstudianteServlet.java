package controladores;

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.transaction.Transaction;
import logica.ClaseEstudiante;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

@WebServlet(name = "registroEstudianteServlet", urlPatterns = {"/registroEstudianteServlet"})
public class RegistroEstudianteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ClaseEstudiante estudiante = new ClaseEstudiante();
        estudiante.setCedula(req.getParameter("cedula"));
        estudiante.setNombre(req.getParameter("nombre"));
        estudiante.setDireccion(req.getParameter("direccion"));
        estudiante.setTelefono(req.getParameter("telefono"));
        estudiante.setCodigoUnico(req.getParameter("codigoUnico"));
        estudiante.setCorreoElectronico(req.getParameter("correoElectronico"));

        // Enviar estudiante a BD
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory()) {
            Session session = sessionFactory.openSession();
            // save the student object
            session.save(estudiante);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void destroy() {
    }
}
